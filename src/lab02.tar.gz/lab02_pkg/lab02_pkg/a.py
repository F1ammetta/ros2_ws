import rclpy
import tf_transformations
from rclpy.node import Node
import math

from std_msgs.msg import String
from std_msgs.msg import Header
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PoseWithCovariance
from geometry_msgs.msg import Pose
from geometry_msgs.msg import TwistWithCovariance
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Vector3
from geometry_msgs.msg import Quaternion
from nav_msgs.msg import Odometry

from rclpy.qos import qos_profile_sensor_data


class Controller(Node):
    # to store robot yaw and angular speed measured from sensors
    w = 0.0
    yaw = 0.0
    
    # State machine states
    STATE_FORWARD = 0
    STATE_ROTATING = 1
    
    # Robot parameters
    OBSTACLE_DISTANCE = 0.45  # 45cm - distance to start avoiding
    FORWARD_SPEED = 0.3  # m/s
    ROTATION_SPEED = 0.8  # rad/s
    FRONT_ANGLE_RANGE = 30  # degrees to check in front (±30 degrees)


    def __init__(self):
        super().__init__('controller')
        self.sub = self.create_subscription(LaserScan, "/scan", self.lidar_cb,
                                 qos_profile_sensor_data)
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.sub = self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

        self.i = 0
        self.state = self.STATE_FORWARD
        self.target_yaw = None
        self.rotation_direction = 1  # 1 for counter-clockwise, -1 for clockwise



    def odom_cb(self, msg: Odometry):
        pose: PoseWithCovariance = msg.pose
        twist: Twist = msg.twist.twist
        qu: Quaternion = pose.pose.orientation
        quat = [qu.x, qu.y, qu.z, qu.w]
        _, _, yaw = tf_transformations.euler_from_quaternion(quat)

        self.yaw = yaw * 180.0 / math.pi
        self.w = twist.angular.z


    def check_front_obstacle(self, dists, min_angle, delta_angle):
        """
        Check if there's an obstacle in front of the robot within OBSTACLE_DISTANCE
        Returns True if obstacle detected, False otherwise
        """
        front_angle_rad = math.radians(self.FRONT_ANGLE_RANGE)
        
        for i, dist in enumerate(dists):
            # Calculate angle for this reading
            angle = min_angle + i * delta_angle
            
            # Check if this reading is in the front sector
            if abs(angle) <= front_angle_rad:
                # Check if distance is valid and below threshold
                if dist > 0 and dist < self.OBSTACLE_DISTANCE:
                    return True
        
        return False


    def find_best_direction(self, dists, min_angle, delta_angle):
        """
        Analyze the surroundings and determine the best direction to rotate
        Returns 1 for counter-clockwise (left), -1 for clockwise (right)
        """
        left_clearance = 0
        right_clearance = 0
        left_count = 0
        right_count = 0
        
        for i, dist in enumerate(dists):
            angle = min_angle + i * delta_angle
            
            # Consider valid readings
            if dist > 0 and dist < 10.0:  # Ignore invalid readings
                if angle > 0:  # Left side
                    left_clearance += dist
                    left_count += 1
                else:  # Right side
                    right_clearance += dist
                    right_count += 1
        
        # Calculate average clearance
        avg_left = left_clearance / left_count if left_count > 0 else 0
        avg_right = right_clearance / right_count if right_count > 0 else 0
        
        # Choose direction with more clearance
        return 1 if avg_left > avg_right else -1


    def normalize_angle(self, angle):
        """Normalize angle to [-180, 180] range"""
        while angle > 180:
            angle -= 360
        while angle < -180:
            angle += 360
        return angle


    def lidar_cb(self, msg: LaserScan):
        vel = Twist()
        vel.linear = Vector3()
        vel.angular = Vector3()

        min_angle = msg.angle_min
        max_angle = msg.angle_max
        delta_angle = msg.angle_increment

        min_dist = msg.range_min
        max_dist = msg.range_max

        # distances in meters, index angles start at min_angle and increment by delta_angle
        dists = msg.ranges

        # Check for obstacles in front
        obstacle_detected = self.check_front_obstacle(dists, min_angle, delta_angle)

        # State machine logic
        if self.state == self.STATE_FORWARD:
            if obstacle_detected:
                # Obstacle detected, switch to rotation state
                self.state = self.STATE_ROTATING
                # Determine rotation direction
                self.rotation_direction = self.find_best_direction(dists, min_angle, delta_angle)
                # Set target yaw (rotate between 60-120 degrees)
                rotation_amount = 60 + (self.i % 60)  # Vary rotation to avoid patterns
                self.target_yaw = self.normalize_angle(
                    self.yaw + rotation_amount * self.rotation_direction
                )
                self.get_logger().info(
                    f'Obstacle detected! Rotating {"left" if self.rotation_direction > 0 else "right"} '
                    f'to {self.target_yaw:.1f}°'
                )
            else:
                # No obstacle, move forward
                vel.linear.x = self.FORWARD_SPEED
                vel.angular.z = 0.0

        elif self.state == self.STATE_ROTATING:
            # Calculate angle difference to target
            angle_diff = self.normalize_angle(self.target_yaw - self.yaw)
            
            # Check if we've rotated enough
            if abs(angle_diff) < 5:  # 5 degree tolerance
                # Check if path is clear now
                if not obstacle_detected:
                    # Path is clear, resume forward movement
                    self.state = self.STATE_FORWARD
                    self.get_logger().info('Path clear, moving forward')
                else:
                    # Still blocked, rotate more
                    rotation_amount = 60 + (self.i % 60)
                    self.target_yaw = self.normalize_angle(
                        self.yaw + rotation_amount * self.rotation_direction
                    )
            
            # Rotate towards target
            vel.linear.x = 0.0
            vel.angular.z = self.ROTATION_SPEED * self.rotation_direction

        self.publisher_.publish(vel)
        self.i += 1


        



def main(args=None):
    rclpy.init(args=args)

    controller = Controller()

    rclpy.spin(controller)

    controller.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
